package exception;

import java.util.Date;

public class ExceptionResponse {
	private Date timestamp;
	private String meaasge;
	private String details;
	
	public ExceptionResponse(Date timestamp, String meaasge, String details) {
		super();
		this.timestamp = timestamp;
		this.meaasge = meaasge;
		this.details = details;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public String getMeaasge() {
		return meaasge;
	}
	public String getDetails() {
		return details;
	}
	
	

}
